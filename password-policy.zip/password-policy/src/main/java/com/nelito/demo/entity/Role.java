package com.nelito.demo.entity;

import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;


@Entity
public class Role {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="role_name")
	private String name;
	
	@ElementCollection
	@CollectionTable(name="message_types", joinColumns=@JoinColumn(name="message_type_id"))
	@Column(name="message_type")
	private List<String> messageType;
	
	@ElementCollection
	@CollectionTable(name="currency_types", joinColumns=@JoinColumn(name="currency_type_id"))
	@Column(name="currency_type")
	private List<String> currencyType;
	
	@ElementCollection
	@CollectionTable(name="password_policies", joinColumns=@JoinColumn(name="password_policy_id"))
	@Column(name="password_policy")
	private List<String> passwordPolicy;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getMessageType() {
		return messageType;
	}

	public void setMessageType(List<String> messageType) {
		this.messageType = messageType;
	}

	public List<String> getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(List<String> currencyType) {
		this.currencyType = currencyType;
	}

	public List<String> getPasswordPolicy() {
		return passwordPolicy;
	}

	public void setPasswordPolicy(List<String> passwordPolicy) {
		this.passwordPolicy = passwordPolicy;
	}
}
