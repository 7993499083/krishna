package com.nelito.demo.entity;

import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class PasswordPolicy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "policy_profile_name")
	private String policyProfileName;

	@ElementCollection
	@CollectionTable(name = "password_complexity_table", joinColumns = @JoinColumn(name = "password_complexity_id"))
	@Column(name = "password_complexity")
	private List<String> passwordComplexity;

	@Column(name = "password_maximum_length")
	private String passwordMaximumLength;

	@Column(name = "consecutive_number")
	private String consecutiveNumber;

	@Column(name = "levinson_validation")
	private String levinsonValidation;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPolicyProfileName() {
		return policyProfileName;
	}

	public void setPolicyProfileName(String policyProfileName) {
		this.policyProfileName = policyProfileName;
	}

	public List<String> getPasswordComplexity() {
		return passwordComplexity;
	}

	public void setPasswordComplexity(List<String> passwordComplexity) {
		this.passwordComplexity = passwordComplexity;
	}

	public String getPasswordMaximumLength() {
		return passwordMaximumLength;
	}

	public void setPasswordMaximumLength(String passwordMaximumLength) {
		this.passwordMaximumLength = passwordMaximumLength;
	}

	public String getConsecutiveNumber() {
		return consecutiveNumber;
	}

	public void setConsecutiveNumber(String consecutiveNumber) {
		this.consecutiveNumber = consecutiveNumber;
	}

	public String getLevinsonValidation() {
		return levinsonValidation;
	}

	public void setLevinsonValidation(String levinsonValidation) {
		this.levinsonValidation = levinsonValidation;
	}

}
