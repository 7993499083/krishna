package com.nelito.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nelito.demo.model.AddRoleRequest;
import com.nelito.demo.model.AddRoleResponse;
import com.nelito.demo.model.PasswordPolicyResponse;
import com.nelito.demo.model.PasswordpolicyRequest;
import com.nelito.demo.service.PasswordPolicyService;
import com.nelito.demo.service.RoleService;

@RestController
public class AppController {

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private PasswordPolicyService passwordPolicyService;

	@PostMapping(path = "/add-role")
	public ResponseEntity<AddRoleResponse> addRole(@RequestBody AddRoleRequest request) {

		return roleService.addRole(request);

	}
	
	@PostMapping(path = "/add-password-policy")
	public ResponseEntity<PasswordPolicyResponse> addPasswordPolicy(@RequestBody PasswordpolicyRequest request) {

		return passwordPolicyService.passwordPolicy(request);

	}

}
