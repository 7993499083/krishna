package com.nelito.demo.model;

import java.util.List;

public class AddRoleRequest {
	
	private String name;
	
	private List<String> messageType;
	
	private List<String> currencyType;
	
	private List<String> passwordPolicy;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getMessageType() {
		return messageType;
	}

	public void setMessageType(List<String> messageType) {
		this.messageType = messageType;
	}

	public List<String> getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(List<String> currencyType) {
		this.currencyType = currencyType;
	}

	public List<String> getPasswordPolicy() {
		return passwordPolicy;
	}

	public void setPasswordPolicy(List<String> passwordPolicy) {
		this.passwordPolicy = passwordPolicy;
	}
	
	

}
