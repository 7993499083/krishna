package com.nelito.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.nelito.demo.entity.PasswordPolicy;
import com.nelito.demo.model.PasswordPolicyResponse;
import com.nelito.demo.model.PasswordpolicyRequest;
import com.nelito.demo.repo.PasswordPolicyRepository;

@Service
public class PasswordPolicyService {
	
	@Autowired
	private PasswordPolicyRepository passwordPolicyRepository;
	
	public ResponseEntity<PasswordPolicyResponse> passwordPolicy(PasswordpolicyRequest request){
		PasswordPolicy passwordPolicy = new PasswordPolicy();
		passwordPolicy.setPolicyProfileName(request.getPolicyProfileName());
		passwordPolicy.setPasswordComplexity(request.getPasswordComplexity());
		passwordPolicy.setPasswordMaximumLength(request.getPasswordMaximumLength());
		passwordPolicy.setConsecutiveNumber(request.getConsecutiveNumber());
		passwordPolicy.setLevinsonValidation(request.getLevinsonValidation());
		
		PasswordPolicy passwordPolicyRes = passwordPolicyRepository.save(passwordPolicy);
		PasswordPolicyResponse passwordPolicyResponse = new PasswordPolicyResponse();
		
		if (passwordPolicyRes != null) {

			passwordPolicyResponse.setResponseCode(200);
			passwordPolicyResponse.setResponseMessage("Password Policy added successfully");
		}

		return new ResponseEntity<>(passwordPolicyResponse, HttpStatus.OK);
		
	}

}
